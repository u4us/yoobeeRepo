import React, {Component} from 'react';

class RouteNotFound extends Component {

  render(){
    return (
      <div class="main">
        <h3>Ooops</h3> 
      </div>
    );
  }
}

export default RouteNotFound;
